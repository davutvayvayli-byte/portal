<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/lib/db.php'; // db() fonksiyonu buradan geliyor

try {
  $pdo = db();
  $one = $pdo->query("SELECT 1 AS ok")->fetch();
  $u = $pdo->query("SELECT COUNT(*) c FROM admin_users")->fetch();

  echo json_encode([
    'ok' => true,
    'db' => true,
    'select1' => $one,
    'admin_users_count' => (int)$u['c'],
    'time' => date('c'),
  ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode([
    'ok' => false,
    'db' => false,
    'error' => 'DB connection failed',
    'detail' => $e->getMessage(),
    'time' => date('c'),
  ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}
