<?php
header('Content-Type: text/plain; charset=utf-8');

$root = __DIR__;
$needles = ['pdo', 'mysqli', 'db_host', 'DB_HOST', 'DB_USER', 'DB_PASS', 'dbname', 'mysql:', 'host', 'user', 'pass', 'CHANGE_ME'];
$maxFiles = 5000;
$scanned = 0;

echo "SCAN ROOT: $root\n\n";

$it = new RecursiveIteratorIterator(
  new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
);

foreach ($it as $file) {
  if ($file->isDir()) continue;
  $path = $file->getPathname();
  $ext  = strtolower(pathinfo($path, PATHINFO_EXTENSION));
  if (!in_array($ext, ['php','inc','env','txt','json','ini'])) continue;

  $scanned++;
  if ($scanned > $maxFiles) break;

  $content = @file_get_contents($path);
  if ($content === false) continue;

  $hit = false;
  foreach ($needles as $n) {
    if (stripos($content, $n) !== false) { $hit = true; break; }
  }
  if (!$hit) continue;

  echo "HITS in: $path\n";
  $lines = explode("\n", $content);
  foreach ($lines as $i => $line) {
    foreach ($needles as $n) {
      if (stripos($line, $n) !== false) {
        $ln = $i + 1;
        echo "  line $ln: " . trim($line) . "\n";
        break;
      }
    }
  }
  echo "\n";
}

echo "DONE. scanned=$scanned\n";
