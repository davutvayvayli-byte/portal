<?php
/**
 * Veritabanı ve Genel Yapılandırma
 * Dosya Yolu: api/config.php
 */
return [
  'db' => [
    'host' => 'localhost',
    'name' => 'vayvayli_ops', // Veritabanı adı
    'user' => 'vayvayli_ops', // Kullanıcı adı
    'pass' => 'Dv103902Dv.',    // Şifre
    'charset' => 'utf8mb4',
  ],
  'cors' => [
    'allowed_origins' => [
      'https://deneme.vayvayli.com',
      'http://localhost:5173',
      'http://127.0.0.1:5173',
      'http://localhost:3000',
    ],
  ],
  'auth' => [
    'token_ttl_minutes' => 60 * 24 * 7, // 7 gün
  ],
  'uploads' => [
    'dir' => __DIR__ . '/uploads',
    'url_base' => '/api/uploads',
    'max_mb' => 20,
    'allowed_mime' => ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4'],
  ],
];