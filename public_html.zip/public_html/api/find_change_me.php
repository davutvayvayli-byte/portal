<?php
header('Content-Type: text/plain; charset=utf-8');

$root = __DIR__;
$needle = "CHANGE_ME";
$maxFiles = 3000;
$scanned = 0;

echo "SCAN ROOT: $root\n\n";

$it = new RecursiveIteratorIterator(
  new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
);

foreach ($it as $file) {
  if ($file->isDir()) continue;

  $path = $file->getPathname();
  $ext  = strtolower(pathinfo($path, PATHINFO_EXTENSION));

  // sadece mantıklı dosyalar
  if (!in_array($ext, ['php','inc','env','txt','json','ini'])) continue;

  $scanned++;
  if ($scanned > $maxFiles) {
    echo "\nSTOP: file limit reached ($maxFiles)\n";
    break;
  }

  $content = @file_get_contents($path);
  if ($content === false) continue;

  if (strpos($content, $needle) !== false) {
    echo "FOUND in: $path\n";
    $lines = explode("\n", $content);
    foreach ($lines as $i => $line) {
      if (strpos($line, $needle) !== false) {
        $ln = $i + 1;
        echo "  line $ln: " . trim($line) . "\n";
      }
    }
    echo "\n";
  }
}

echo "DONE. scanned=$scanned\n";
