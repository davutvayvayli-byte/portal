<?php
/**
 * API Ana Giriş Dosyası - Rota Yönetimi ve Hata Ayıklama
 */

// Hataları ekrana bas (Geliştirme bittikten sonra kapatılabilir)
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/lib/response.php';
require_once __DIR__ . '/lib/cors.php';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/auth.php';

// Eğer upload.php varsa yükle, yoksa hata vermesini önleyelim
if (file_exists(__DIR__ . '/lib/upload.php')) {
    require_once __DIR__ . '/lib/upload.php';
}

// CORS ayarlarını uygula
apply_cors();

// Rota (URL Path) çözümleme motoru
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
$basePath = rtrim(dirname($scriptName), '/');

$path = parse_url($requestUri, PHP_URL_PATH);
if ($basePath && str_starts_with($path, $basePath)) {
    $path = substr($path, strlen($basePath));
}
$path = '/' . ltrim($path, '/');

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// Veritabanı bağlantısı
$pdo = db();

/**
 * Veritabanı verilerini dışa aktarma fonksiyonu
 */
function export_snapshot(PDO $pdo): array {
    $tables = [
        'settings' => "SELECT `key`,`value` FROM portal_settings",
        'categories' => "SELECT id,name,color,is_active,sort_order FROM portal_categories ORDER BY sort_order ASC, id ASC",
        'pages' => "SELECT id,title,slug,content,is_active,sort_order FROM portal_pages ORDER BY sort_order ASC, id ASC",
        'menus' => "SELECT id,menu_title,url,parent_id,sort,is_active FROM portal_menus ORDER BY sort ASC, id ASC",
        'news' => "SELECT id,category_id,title,slug,summary,content,date,image,views,is_active,author FROM portal_news ORDER BY id DESC",
        'blocks' => "SELECT id,column_type,block_title,block_type,module_id,html_content,sort_order,is_active FROM portal_blocks ORDER BY sort_order ASC, id ASC",
        'banners' => "SELECT id,image_path,title,link_url,sort_order,is_active FROM portal_banners ORDER BY sort_order ASC, id ASC",
        'messages' => "SELECT id,name,email,subject,message,is_read,created_at FROM portal_messages ORDER BY created_at DESC, id DESC",
        'media' => "SELECT id,filename,original_name,mime,size,url,created_at FROM portal_media ORDER BY id DESC"
    ];
    
    $res = [];
    foreach ($tables as $key => $sql) {
        try {
            $stmt = $pdo->query($sql);
            $res[$key] = $stmt ? $stmt->fetchAll() : [];
        } catch (Exception $e) {
            $res[$key] = [];
        }
    }

    try {
        $galleries = $pdo->query("SELECT id,title,slug,cover,count,is_active,sort_order FROM portal_galleries ORDER BY sort_order ASC, id ASC")->fetchAll();
        if ($galleries) {
            $stmt = $pdo->prepare("SELECT id,gallery_id,type,src,caption,sort_order FROM portal_gallery_items WHERE gallery_id=:gid ORDER BY sort_order ASC, id ASC");
            foreach ($galleries as &$g) {
                $stmt->execute([':gid' => $g['id']]);
                $g['items'] = $stmt->fetchAll();
            }
            unset($g);
        }
        $res['galleries'] = $galleries;
    } catch (Exception $e) {
        $res['galleries'] = [];
    }

    return $res;
}

// --- API Rotaları ---

// 1. Sağlık Kontrolü
if ($path === '/health') {
    json_response(['ok' => true, 'time' => date('c'), 'path' => $path]);
}

// 2. Uploads Klasörüne Erişim
if (str_starts_with($path, '/uploads/')) {
    $file = basename($path);
    $cfg = require __DIR__ . '/config.php';
    $full = rtrim($cfg['uploads']['dir'], '/') . '/' . $file;
    if (!is_file($full)) {
        http_response_code(404);
        exit;
    }
    $mime = mime_content_type($full) ?: 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Cache-Control: public, max-age=31536000');
    readfile($full);
    exit;
}

// 3. Admin Girişi (POST /auth/login)
if ($path === '/auth/login' && $method === 'POST') {
    $body = read_json_body();
    $username = (string)($body['username'] ?? '');
    $password = (string)($body['password'] ?? '');
    
    if (!$username || !$password) {
        json_response(['error' => 'Kullanıcı adı veya şifre boş'], 400);
    }
    
    json_response(login_user($username, $password));
}

// 4. İletişim Formu (Public)
if ($path === '/public/message' && $method === 'POST') {
    $body = read_json_body();
    $name = trim((string)($body['name'] ?? ''));
    $email = trim((string)($body['email'] ?? ''));
    $subject = trim((string)($body['subject'] ?? ''));
    $message = trim((string)($body['message'] ?? ''));
    
    if ($name === '' || $email === '' || $message === '') {
        json_response(['error' => 'Gerekli alanlar eksik'], 400);
    }

    $stmt = $pdo->prepare("INSERT INTO portal_messages (name, email, subject, message, is_read, created_at)
                           VALUES (:n, :e, :s, :m, 0, NOW())");
    $stmt->execute([':n' => $name, ':e' => $email, ':s' => $subject, ':m' => $message]);
    json_response(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
}

// 5. Genel Verileri Çekme (Public)
if ($path === '/public/snapshot' && $method === 'GET') {
    json_response(export_snapshot($pdo));
}

// 6. Admin Paneli İşlemleri (Token Korumalı)
if (str_starts_with($path, '/admin/')) {
    require_auth(); 
    
    if ($path === '/admin/export' && $method === 'GET') {
        json_response(export_snapshot($pdo));
    }
    
    if ($path === '/admin/media/upload' && $method === 'POST') {
        if (function_exists('handle_media_upload')) {
            $media = handle_media_upload();
            json_response(['ok' => true, 'media' => $media]);
        } else {
            json_response(['error' => 'Upload sistemi yüklenemedi'], 500);
        }
    }
}

// Tanımsız Rota
json_response(['error' => 'API rotası bulunamadı', 'path' => $path], 404);