<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/response.php';

function ensure_upload_dir(string $dir): void {
  if (!is_dir($dir)) {
    if (!mkdir($dir, 0775, true) && !is_dir($dir)) {
      json_response(['error'=>'Cannot create uploads dir'], 500);
    }
  }
}

function handle_media_upload(): array {
  $cfg = require __DIR__ . '/../config.php';
  $up = $cfg['uploads'];
  $dir = $up['dir'];
  $maxBytes = ((int)$up['max_mb']) * 1024 * 1024;
  $allowed = $up['allowed_mime'];

  if (!isset($_FILES['file'])) json_response(['error'=>'Missing file field'], 400);
  $f = $_FILES['file'];
  if ($f['error'] !== UPLOAD_ERR_OK) json_response(['error'=>'Upload error', 'code'=>$f['error']], 400);
  if ($f['size'] > $maxBytes) json_response(['error'=>'File too large'], 413);

  $tmp = $f['tmp_name'];
  $mime = mime_content_type($tmp) ?: $f['type'];
  if ($allowed && !in_array($mime, $allowed, true)) {
    json_response(['error'=>'Unsupported mime', 'mime'=>$mime], 415);
  }

  ensure_upload_dir($dir);

  $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
  $safeExt = preg_replace('/[^a-zA-Z0-9]/', '', $ext);
  $name = date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . ($safeExt ? ('.'.$safeExt) : '');
  $dest = rtrim($dir,'/') . '/' . $name;
  if (!move_uploaded_file($tmp, $dest)) json_response(['error'=>'Failed to save file'], 500);

  $url = rtrim($up['url_base'], '/') . '/' . $name;

  $pdo = db();
  $pdo->prepare("INSERT INTO portal_media (filename, original_name, mime, size, url, created_at)
                 VALUES (:fn,:on,:mime,:sz,:url,NOW())")
      ->execute([
        ':fn'=>$name,
        ':on'=>$f['name'],
        ':mime'=>$mime,
        ':sz'=>$f['size'],
        ':url'=>$url,
      ]);
  $id = (int)$pdo->lastInsertId();

  return ['id'=>$id,'filename'=>$name,'original_name'=>$f['name'],'mime'=>$mime,'size'=>$f['size'],'url'=>$url,'created_at'=>date('Y-m-d H:i:s')];
}
