<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/response.php';

function require_auth(): array {
  $token = get_bearer_token();
  if (!$token) json_response(['error'=>'Missing Authorization Bearer token'], 401);

  $pdo = db();
  $hash = hash('sha256', $token);
  $stmt = $pdo->prepare("SELECT t.id, t.user_id, t.expires_at, u.username
                         FROM admin_tokens t
                         JOIN admin_users u ON u.id = t.user_id
                         WHERE t.token_hash = :h LIMIT 1");
  $stmt->execute([':h'=>$hash]);
  $row = $stmt->fetch();
  if (!$row) json_response(['error'=>'Invalid token'], 401);
  if (strtotime($row['expires_at']) < time()) json_response(['error'=>'Token expired'], 401);

  return $row;
}

function login_user(string $username, string $password): array {
  $pdo = db();
  $stmt = $pdo->prepare("SELECT id, username, password_hash FROM admin_users WHERE username=:u LIMIT 1");
  $stmt->execute([':u'=>$username]);
  $u = $stmt->fetch();
  if (!$u || !password_verify($password, $u['password_hash'])) {
    json_response(['error'=>'Invalid username or password'], 401);
  }

  $cfg = require __DIR__ . '/../config.php';
  $ttl = (int)($cfg['auth']['token_ttl_minutes'] ?? 10080);
  $expires = date('Y-m-d H:i:s', time() + $ttl*60);

  $token = bin2hex(random_bytes(32));
  $hash = hash('sha256', $token);

  $pdo->prepare("INSERT INTO admin_tokens (user_id, token_hash, expires_at, created_at)
                 VALUES (:uid,:h,:exp,NOW())")
      ->execute([':uid'=>$u['id'], ':h'=>$hash, ':exp'=>$expires]);

  return ['token'=>$token, 'expires_at'=>$expires, 'user'=>['id'=>$u['id'], 'username'=>$u['username']]];
}
