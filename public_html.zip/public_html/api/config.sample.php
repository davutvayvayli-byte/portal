<?php
// Copy this file to config.php and fill your DB credentials.
return [
  'db' => [
    'host' => 'localhost',
    'name' => 'YOUR_DB_NAME',
    'user' => 'YOUR_DB_USER',
    'pass' => 'YOUR_DB_PASS',
    'charset' => 'utf8mb4',
  ],
  // Set allowed origins for CORS. Use ['*'] to allow all (not recommended).
  'cors' => [
    'allowed_origins' => [
      'https://deneme.vayvayli.com',
      'http://localhost:5173',
      'http://127.0.0.1:5173',
    ],
  ],
  // Token settings (minutes)
  'auth' => [
    'token_ttl_minutes' => 60*24*7, // 7 days
  ],
  // Uploads (relative to api/ directory)
  'uploads' => [
    'dir' => __DIR__ . '/uploads',
    'url_base' => '/api/uploads',
    'max_mb' => 20,
    'allowed_mime' => ['image/jpeg','image/png','image/webp','image/gif','video/mp4'],
  ],
];
