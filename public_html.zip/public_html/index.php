<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vayvaylı Portal</title>
    <!-- Tailwind CSS CDN (Hızlı prototip için) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50 text-gray-900 min-h-screen flex flex-col">

    <!-- Basit Navigasyon -->
    <nav class="bg-white shadow-sm p-4">
        <div class="container mx-auto flex justify-between items-center">
            <h1 class="text-xl font-bold text-blue-600">Vayvaylı Portal</h1>
            <div class="space-x-4">
                <a href="/" class="hover:text-blue-500">Ana Sayfa</a>
                <a href="/api/status" class="text-gray-500 hover:text-blue-500" target="_blank">API Durumu</a>
            </div>
        </div>
    </nav>

    <!-- Ana İçerik -->
    <main class="flex-grow container mx-auto p-6 flex items-center justify-center">
        <div class="text-center bg-white p-8 rounded-xl shadow-lg max-w-md w-full">
            <h2 class="text-2xl font-semibold mb-4 text-gray-800">Hoş Geldiniz</h2>
            <p class="text-gray-600 mb-6">
                Vayvaylı Portal başarıyla yapılandırıldı. API ve Frontend katmanları artık ayrıştırılmış durumda.
            </p>
            <div id="api-test" class="p-4 bg-blue-50 rounded-lg text-sm text-blue-700 font-mono">
                API Test Ediliyor...
            </div>
        </div>
    </main>

    <footer class="p-4 text-center text-gray-400 text-sm">
        &copy; 2024 Vayvaylı Portal - Tüm Hakları Saklıdır.
    </footer>

    <script>
        // API bağlantısını test eden basit bir script
        async function checkAPI() {
            try {
                const response = await fetch('/api/status');
                const data = await response.json();
                document.getElementById('api-test').innerText = 'API Durumu: ' + (data.status || 'Aktif');
            } catch (error) {
                document.getElementById('api-test').innerText = 'API Hatası: Bağlantı kurulamadı.';
                document.getElementById('api-test').classList.replace('bg-blue-50', 'bg-red-50');
                document.getElementById('api-test').classList.replace('text-blue-700', 'text-red-700');
            }
        }
        
        window.onload = checkAPI;
    </script>
</body>
</html>