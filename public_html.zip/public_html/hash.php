<?php
echo password_hash('Admin123!', PASSWORD_BCRYPT);
